package com.example.shashank.myapplication

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.Button
import android.widget.Toast
import java.net.URL


class Action2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_action2)
        val button=findViewById<Button>(R.id.button)
        val button1=findViewById<Button>(R.id.button2)
        button.setOnClickListener {
            Toast.makeText(applicationContext,"click the button on1",Toast.LENGTH_LONG).show()
            val Int = Intent(this@Action2,Action3::class.java)
            startActivity(Int)
        }
        /*button1.setOnClickListener {
            Toast.makeText(applicationContext,"click the button on2",Toast.LENGTH_LONG).show()
            val In = Intent(this@Action2,Action4::class.java)
            startActivity(In)
        }*/

    }
}