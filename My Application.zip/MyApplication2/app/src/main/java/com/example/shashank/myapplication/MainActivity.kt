package com.example.shashank.myapplication

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.Gravity
import android.widget.Toast

class MainActivity : AppCompatActivity() {
 val i =5000
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toast=Toast.makeText(applicationContext,"welcome to my application",Toast.LENGTH_LONG)
        toast.setGravity(Gravity.CENTER,0, 0)
        toast.show()
        Handler().postDelayed({
         val Intent = Intent(this@MainActivity,Action2::class.java)
        startActivity(Intent)
        finish()
        },5000)

    }

}
